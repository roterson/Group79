import setuptools

setuptools.setup(
    name= 'dlproject',
    version= '1',
    packages = setuptools.find_packages(),
    author='shuofu',
    author_email='shuofu1997@outlook.com',
)
